import person;
import <iostream>;
import <sstream>;
import <fstream>;

using namespace std;

int main()
{
	Person person{ "John", "Doe" };
.
	person.output(cout);

	ostringstream oss;
	person.output(oss);
	cout << oss.str() << endl;

	ofstream outFile{ "person.txt" };
	person.output(outFile);
}
